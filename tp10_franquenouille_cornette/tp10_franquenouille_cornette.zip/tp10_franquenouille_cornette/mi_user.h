#define MATRIX_SIZE 10

void init();
